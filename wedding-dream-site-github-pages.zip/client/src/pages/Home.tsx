import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Heart } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-rose-50 via-white to-amber-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-rose-100">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="w-6 h-6 text-rose-600 fill-rose-600" />
            <h1 className="text-2xl font-bold text-rose-900">João & Maria</h1>
          </div>
          <nav className="hidden md:flex gap-8">
            <a href="#planejamento" className="text-sm font-medium text-gray-700 hover:text-rose-600 transition">
              Planejamento
            </a>
            <a href="#festa" className="text-sm font-medium text-gray-700 hover:text-rose-600 transition">
              Festa
            </a>
            <a href="#casa" className="text-sm font-medium text-gray-700 hover:text-rose-600 transition">
              Casa
            </a>
            <a href="#presentes" className="text-sm font-medium text-gray-700 hover:text-rose-600 transition">
              Presentes
            </a>
            <a href="#cerimonia" className="text-sm font-medium text-gray-700 hover:text-rose-600 transition">
              Cerimônia
            </a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-96 bg-gradient-to-br from-rose-900 via-amber-800 to-rose-800 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 right-0 w-96 h-96 bg-rose-400 rounded-full mix-blend-multiply filter blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-300 rounded-full mix-blend-multiply filter blur-3xl"></div>
        </div>
        <div className="relative h-full flex flex-col items-center justify-center text-center px-4">
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-4 font-serif">Nosso Sonho</h2>
          <p className="text-xl text-rose-100">Uma celebração do amor e do compromisso</p>
        </div>
      </section>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-16">
        {/* Planejamento Geral */}
        <section id="planejamento" className="mb-20">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-1 h-8 bg-rose-600"></div>
            <h2 className="text-3xl font-bold text-gray-900">Planejamento Geral</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-rose-200 bg-white/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-rose-900">Salários e Contribuições</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-rose-100">
                  <span className="text-gray-700">João Tolerante (Mensal):</span>
                  <span className="font-semibold text-amber-700">R$ 0,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-rose-100">
                  <span className="text-gray-700">Maria Sossegada (Mensal):</span>
                  <span className="font-semibold text-amber-700">R$ 1.460,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-rose-100">
                  <span className="text-gray-700">Contribuição Total (Mensal):</span>
                  <span className="font-semibold text-amber-700">R$ 7.120,00</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border-rose-200 bg-white/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-rose-900">Resumo Financeiro</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-rose-100">
                  <span className="text-gray-700">Férias (13º):</span>
                  <span className="font-semibold text-rose-700">R$ 1.460,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-rose-100">
                  <span className="text-gray-700">Disponível por Mês:</span>
                  <span className="font-semibold text-rose-700">R$ 8.080,00</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-700">Máximo para Mobiliar:</span>
                  <span className="font-semibold text-rose-700">R$ 8.080,00</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Orçamento da Festa */}
        <section id="festa" className="mb-20">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-1 h-8 bg-amber-600"></div>
            <h2 className="text-3xl font-bold text-gray-900">Orçamento da Festa</h2>
          </div>

          <Card className="border-amber-200 bg-white/50 backdrop-blur mb-8">
            <CardHeader>
              <CardTitle className="text-amber-900">Detalhamento</CardTitle>
              <CardDescription className="text-lg font-semibold text-amber-700">R$ 60.980,44</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                {[
                  { item: "Cerimônia + Assessoria", valor: "R$ 5.500,00" },
                  { item: "Casamento Civil", valor: "R$ 2.730,44" },
                  { item: "Igreja / Local Religioso", valor: "R$ 1.050,00" },
                  { item: "Espaço de Festas", valor: "R$ 5.000,00" },
                  { item: "Buffet Completo", valor: "R$ 6.000,00" },
                  { item: "Decoração", valor: "R$ 5.500,00" },
                  { item: "Foto e Filmagem", valor: "R$ 4.500,00" },
                  { item: "Bolo e Doces", valor: "R$ 2.500,00" },
                  { item: "Viagem de Lua de Mel", valor: "R$ 10.000,00" },
                ].map((item, idx) => (
                  <div key={idx} className="p-4 bg-amber-50 rounded-lg border border-amber-100">
                    <p className="text-sm text-gray-700 mb-2">{item.item}</p>
                    <p className="text-lg font-bold text-amber-700">{item.valor}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-amber-200 bg-white/50 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-amber-900">Observações Importantes</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-gray-700">
                <li>• Planejamento e coordenação no dia da cerimônia</li>
                <li>• Taxa de reserva e decoração básica inclusos</li>
                <li>• Estimado para 60 convidados (R$ 100/pessoa)</li>
                <li>• Mobiliário extra, flores e cenografia profissional</li>
                <li>• Cobertura completa + Álbum + Vídeo</li>
                <li>• Equipamento profissional e produtor</li>
                <li>• Impressos e digitais</li>
                <li>• Reserva para despesas imediatas pós-casamento</li>
                <li>• Alianças de casamento civil e religioso</li>
              </ul>
            </CardContent>
          </Card>
        </section>

        {/* Casa e Mobília */}
        <section id="casa" className="mb-20">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-1 h-8 bg-blue-600"></div>
            <h2 className="text-3xl font-bold text-gray-900">Casa e Mobília</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-blue-200 bg-white/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-blue-900">Despesas da Casa</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-blue-100">
                  <span className="text-gray-700">Aluguel + Gás</span>
                  <span className="font-semibold text-blue-700">R$ 1.600,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-blue-100">
                  <span className="text-gray-700">Condomínio</span>
                  <span className="font-semibold text-blue-700">R$ 250,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-blue-100">
                  <span className="text-gray-700">Água</span>
                  <span className="font-semibold text-blue-700">R$ 150,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-blue-100">
                  <span className="text-gray-700">Luz + Internet</span>
                  <span className="font-semibold text-blue-700">R$ 200,00</span>
                </div>
                <div className="flex justify-between items-center py-3 bg-blue-50 px-3 rounded font-bold">
                  <span className="text-blue-900">Total Mensal</span>
                  <span className="text-blue-700">R$ 2.200,00</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border-blue-200 bg-white/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-blue-900">Mobília por Cômodo</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-blue-100">
                  <span className="text-gray-700">Sala de Estar</span>
                  <span className="font-semibold text-rose-700">R$ 5.450,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-blue-100">
                  <span className="text-gray-700">Cozinha</span>
                  <span className="font-semibold text-rose-700">R$ 8.900,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-blue-100">
                  <span className="text-gray-700">Quarto</span>
                  <span className="font-semibold text-rose-700">R$ 6.300,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-blue-100">
                  <span className="text-gray-700">Banheiro</span>
                  <span className="font-semibold text-rose-700">R$ 768,00</span>
                </div>
                <div className="flex justify-between items-center py-3 bg-blue-50 px-3 rounded font-bold">
                  <span className="text-blue-900">Total Mobília</span>
                  <span className="text-rose-700">R$ 21.418,00</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Lista de Presentes */}
        <section id="presentes" className="mb-20">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-1 h-8 bg-emerald-600"></div>
            <h2 className="text-3xl font-bold text-gray-900">Lista de Presentes</h2>
          </div>

          <div className="space-y-8">
            {/* Cozinha */}
            <Card className="border-emerald-200 bg-white/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-emerald-900">Cozinha / Área de Serviço</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {[
                    { item: "Geladeira Frost Free (Compacta)", valor: "R$ 2.300,00" },
                    { item: "Fogão 4 Bocas / Cooktop + Forno", valor: "R$ 1.200,00" },
                    { item: "Máquina de Lavar Roupas", valor: "R$ 2.200,00" },
                    { item: "Micro-ondas", valor: "R$ 800,00" },
                    { item: "Utensílios Básicos", valor: "R$ 300,00" },
                    { item: "Armários Modulados Cozinha", valor: "R$ 2.500,00" },
                  ].map((item, idx) => (
                    <div key={idx} className="p-3 bg-emerald-50 rounded-lg border border-emerald-100">
                      <p className="text-sm text-gray-700 mb-1">{item.item}</p>
                      <p className="text-base font-bold text-emerald-700">{item.valor}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Sala de Estar */}
            <Card className="border-emerald-200 bg-white/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-emerald-900">Sala de Estar / Jantar</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {[
                    { item: "Sofá 3 Lugares", valor: "R$ 2.500,00" },
                    { item: "Painel de TV + Rack", valor: "R$ 700,00" },
                    { item: "TV 43\" Smart", valor: "R$ 1.700,00" },
                    { item: "Mesa de Jantar 4 Cadeiras", valor: "R$ 1.800,00" },
                    { item: "Mesa de Centro Pequena", valor: "R$ 400,00" },
                    { item: "Tapete", valor: "R$ 150,00" },
                  ].map((item, idx) => (
                    <div key={idx} className="p-3 bg-emerald-50 rounded-lg border border-emerald-100">
                      <p className="text-sm text-gray-700 mb-1">{item.item}</p>
                      <p className="text-base font-bold text-emerald-700">{item.valor}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quarto */}
            <Card className="border-emerald-200 bg-white/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-emerald-900">Quarto</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {[
                    { item: "Cama Box Casal + Colchão", valor: "R$ 3.000,00" },
                    { item: "Criado Mudo", valor: "R$ 350,00" },
                    { item: "Roupa de Cama", valor: "R$ 450,00" },
                    { item: "Cortinas", valor: "R$ 300,00" },
                    { item: "Guarda-roupa Casal", valor: "R$ 2.200,00" },
                  ].map((item, idx) => (
                    <div key={idx} className="p-3 bg-emerald-50 rounded-lg border border-emerald-100">
                      <p className="text-sm text-gray-700 mb-1">{item.item}</p>
                      <p className="text-base font-bold text-emerald-700">{item.valor}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Banheiro */}
            <Card className="border-emerald-200 bg-white/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-emerald-900">Banheiro / Diversos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {[
                    { item: "Utensílios e Decoração Inicial", valor: "R$ 768,00" },
                    { item: "Eletrodomésticos - Utilidades", valor: "R$ 350,00" },
                    { item: "Tapete", valor: "R$ 150,00" },
                    { item: "Liquidificador Básico", valor: "R$ 150,00" },
                    { item: "Air Fryer", valor: "R$ 300,00" },
                    { item: "Ferro de Passar Roupa", valor: "R$ 250,00" },
                    { item: "Aspirador de Pó Compacto", valor: "R$ 650,00" },
                    { item: "Ventilador", valor: "R$ 450,00" },
                  ].map((item, idx) => (
                    <div key={idx} className="p-3 bg-emerald-50 rounded-lg border border-emerald-100">
                      <p className="text-sm text-gray-700 mb-1">{item.item}</p>
                      <p className="text-base font-bold text-emerald-700">{item.valor}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Resumo Total */}
            <Card className="border-emerald-300 bg-gradient-to-r from-emerald-50 to-emerald-100">
              <CardHeader>
                <CardTitle className="text-emerald-900 text-2xl">Total da Lista de Presentes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <p className="text-5xl font-bold text-emerald-700">R$ 27.568,00</p>
                  <p className="text-gray-700 mt-3">Investimento completo em móveis e eletrodomésticos para a casa dos sonhos</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Cerimônias */}
        <section id="cerimonia" className="mb-20">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-1 h-8 bg-purple-600"></div>
            <h2 className="text-3xl font-bold text-gray-900">Cerimônias</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-purple-200 bg-white/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-purple-900">Casamento Civil</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-purple-100">
                  <span className="text-gray-700">Local do Cartório</span>
                  <span className="font-semibold text-purple-700">Rua do Registro Civil</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-purple-100">
                  <span className="text-gray-700">Taxa do Serviço</span>
                  <span className="font-semibold text-purple-700">R$ 293,14</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-purple-100">
                  <span className="text-gray-700">Atualização de Certidões</span>
                  <span className="font-semibold text-purple-700">R$ 436,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-purple-100">
                  <span className="text-gray-700">Roupa da Noiva (Vestido)</span>
                  <span className="font-semibold text-purple-700">R$ 602,00</span>
                </div>
                <div className="flex justify-between items-center py-3 bg-purple-50 px-3 rounded font-bold">
                  <span className="text-purple-900">Total Civil</span>
                  <span className="text-purple-700">R$ 1.331,14</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border-purple-200 bg-white/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-purple-900">Casamento Religioso</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-purple-100">
                  <span className="text-gray-700">Igreja / Local Religioso</span>
                  <span className="font-semibold text-purple-700">R$ 1.000,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-purple-100">
                  <span className="text-gray-700">Decoração Simples</span>
                  <span className="font-semibold text-purple-700">R$ 1.050,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-purple-100">
                  <span className="text-gray-700">Foto / Filmagem</span>
                  <span className="font-semibold text-purple-700">R$ 1.000,00</span>
                </div>
                <div className="flex justify-between items-center py-3 bg-purple-50 px-3 rounded font-bold">
                  <span className="text-purple-900">Total Religioso</span>
                  <span className="text-purple-700">R$ 3.050,00</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Cronograma de Pagamentos */}
        <section className="mb-20">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-1 h-8 bg-green-600"></div>
            <h2 className="text-3xl font-bold text-gray-900">Cronograma de Pagamentos</h2>
          </div>

          <Card className="border-green-200 bg-white/50 backdrop-blur overflow-x-auto">
            <CardContent className="p-6">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b-2 border-green-200">
                    <th className="text-left py-3 px-4 text-green-900 font-bold">Mês</th>
                    <th className="text-right py-3 px-4 text-green-900 font-bold">Contribuição João</th>
                    <th className="text-right py-3 px-4 text-green-900 font-bold">Contribuição Maria</th>
                    <th className="text-right py-3 px-4 text-green-900 font-bold">Total Disponível</th>
                    <th className="text-right py-3 px-4 text-green-900 font-bold">Gasto no Mês</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { mes: "Janeiro", joao: "R$ 0,00", maria: "R$ 3.700,00", total: "R$ 7.120,00", gasto: "-" },
                    { mes: "Fevereiro", joao: "R$ 0,00", maria: "R$ 1.460,00", total: "R$ 7.120,00", gasto: "R$ 8.600,00" },
                    { mes: "Março", joao: "R$ 0,00", maria: "R$ 1.460,00", total: "R$ 7.120,00", gasto: "-" },
                    { mes: "Abril", joao: "R$ 0,00", maria: "R$ 1.460,00", total: "R$ 7.120,00", gasto: "R$ 6.000,00" },
                    { mes: "Maio", joao: "R$ 0,00", maria: "R$ 1.460,00", total: "R$ 7.120,00", gasto: "-" },
                  ].map((row, idx) => (
                    <tr key={idx} className="border-b border-green-100 hover:bg-green-50/50">
                      <td className="py-3 px-4 text-gray-700 font-medium">{row.mes}</td>
                      <td className="py-3 px-4 text-right text-gray-700">{row.joao}</td>
                      <td className="py-3 px-4 text-right text-gray-700">{row.maria}</td>
                      <td className="py-3 px-4 text-right text-green-700 font-semibold">{row.total}</td>
                      <td className="py-3 px-4 text-right text-green-700 font-semibold">{row.gasto}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>
        </section>

        {/* Orçamento de Despesas Mensais */}
        <section className="mb-20">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-1 h-8 bg-indigo-600"></div>
            <h2 className="text-3xl font-bold text-gray-900">Orçamento de Despesas Mensais</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-indigo-200 bg-white/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-indigo-900">João Tolerante</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-indigo-100">
                  <span className="text-gray-700">Transporte:</span>
                  <span className="font-semibold text-indigo-700">R$ 130,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-indigo-100">
                  <span className="text-gray-700">Comida:</span>
                  <span className="font-semibold text-indigo-700">R$ 230,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-indigo-100">
                  <span className="text-gray-700">Lazer:</span>
                  <span className="font-semibold text-indigo-700">R$ 120,00</span>
                </div>
                <div className="flex justify-between items-center py-3 bg-indigo-50 px-3 rounded font-bold">
                  <span className="text-indigo-900">Total Mensal:</span>
                  <span className="text-indigo-700">R$ 480,00</span>
                </div>
                <div className="flex justify-between items-center py-2 text-sm text-gray-600">
                  <span>Anual (12 meses):</span>
                  <span>R$ 5.760,00</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border-indigo-200 bg-white/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-indigo-900">Maria Sossegada</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-indigo-100">
                  <span className="text-gray-700">Transporte:</span>
                  <span className="font-semibold text-indigo-700">R$ 130,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-indigo-100">
                  <span className="text-gray-700">Comida:</span>
                  <span className="font-semibold text-indigo-700">R$ 230,00</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-indigo-100">
                  <span className="text-gray-700">Lazer:</span>
                  <span className="font-semibold text-indigo-700">R$ 120,00</span>
                </div>
                <div className="flex justify-between items-center py-3 bg-indigo-50 px-3 rounded font-bold">
                  <span className="text-indigo-900">Total Mensal:</span>
                  <span className="text-indigo-700">R$ 480,00</span>
                </div>
                <div className="flex justify-between items-center py-2 text-sm text-gray-600">
                  <span>Anual (12 meses):</span>
                  <span>R$ 5.760,00</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-rose-900 to-amber-900 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex justify-center gap-2 mb-4">
            <Heart className="w-5 h-5 fill-rose-300 text-rose-300" />
            <Heart className="w-5 h-5 fill-rose-300 text-rose-300" />
            <Heart className="w-5 h-5 fill-rose-300 text-rose-300" />
          </div>
          <p className="text-lg font-serif mb-2">Nosso Sonho de Casamento • João & Maria</p>
          <p className="text-sm text-rose-100">Planejamento e Orçamento Detalhado</p>
          <p className="text-xs text-rose-200 mt-4">© 2026 - Todos os direitos reservados</p>
        </div>
      </footer>
    </div>
  );
}
